import os,sys,tempfile
os.environ['DB_PATH']=tempfile.mktemp(suffix='.sqlite3')
os.environ['DEV_AUTH']='true'
sys.path.insert(0,os.path.abspath('backend'))
from fastapi.testclient import TestClient
import main
client=TestClient(main.app)
def token(): return {'Authorization':'Bearer '+client.post('/auth/google',json={'id_token':'local-dev'}).json()['token']}
def test_auth_required(): assert client.get('/messages').status_code==403 or client.get('/messages').status_code==401
def test_login_logout():
    h=token(); assert client.get('/messages',headers=h).status_code==200
    assert client.post('/auth/logout',headers=h).status_code==200
    assert client.get('/messages',headers=h).status_code==401
def test_invalid_task():
    assert client.post('/tasks',headers=token(),json={'prompt':'','api_key':'short'}).status_code==422
def test_job_isolation():
    h=token()
    with main.db() as c:c.execute('INSERT INTO jobs VALUES(?,?,?,?,?)',('private','someone-else','done','[]',None))
    assert client.get('/tasks/private',headers=h).status_code==404
    assert client.post('/tasks/private/cancel',headers=h).status_code==404
def test_tool_quotes():
    from sandboxes import tool
    class Box:
        def execute(self,command):self.command=command;return {'exit_code':0}
    box=Box(); tool(box,'write_file',{'path':'/workspace/a.txt','content':"x'; $(touch /host-file)"})
    import shlex
    assert shlex.split(box.command)[0:2]==['python3','-c']
    compile(shlex.split(box.command)[2],'<test>','exec')
def test_agent_loop(monkeypatch):
    import time
    from google.genai import types
    class Box:
        id='test-sandbox'
        def execute(self,c): return {'exit_code':0,'output':'hello'}
    class Models:
        count=0
        def generate_content(self,**kwargs):
            self.count+=1
            part=types.Part(function_call=types.FunctionCall(name='run_shell',args={'command':'echo hello'},id='call1')) if self.count==1 else types.Part(text='Created and checked your result.')
            return types.GenerateContentResponse(candidates=[types.Candidate(content=types.Content(role='model',parts=[part]))])
    class Client:
        def __init__(self,**kwargs):self.models=Models()
        def close(self):pass
    monkeypatch.setattr(main,'workspace',lambda u:Box())
    monkeypatch.setattr(main.genai,'Client',Client)
    h=token(); r=client.post('/tasks',headers=h,json={'prompt':'Say hello','api_key':'test-key-not-real'})
    assert r.status_code==200
    for _ in range(100):
        result=client.get('/tasks/'+r.json()['id'],headers=h).json()
        if result['status']!='running':break
        time.sleep(.01)
    assert result['status']=='done'
    assert [e['kind'] for e in result['events']]==['status','status','tool','result','text']
    assert client.get('/messages',headers=h).json()[-1]['role']=='assistant'
def test_libsql_database_adapter(monkeypatch,tmp_path):
    import libsql,database
    actual=libsql.connect
    path=str(tmp_path/'remote.db')
    monkeypatch.setenv('TURSO_DATABASE_URL','libsql://test-host')
    monkeypatch.setenv('TURSO_AUTH_TOKEN','test-only')
    monkeypatch.setattr(libsql,'connect',lambda **kwargs:actual(path))
    with database.connect('unused') as c:
        c.executescript('CREATE TABLE things(id INTEGER PRIMARY KEY, value TEXT);')
        c.execute('INSERT INTO things(value) VALUES(?)',('persistent',))
    with database.connect('unused') as c:
        r=c.execute('SELECT * FROM things').fetchone()
        assert r['value']=='persistent' and r[0]==1
        assert dict(r)=={'id':1,'value':'persistent'}
def test_google_allowlist(monkeypatch):
    monkeypatch.setenv('DEV_AUTH','false')
    monkeypatch.setenv('GOOGLE_WEB_CLIENT_ID','web-client-id')
    monkeypatch.setenv('ALLOWED_GOOGLE_EMAILS','inetixus@gmail.com')
    monkeypatch.setattr(main.id_token,'verify_oauth2_token',lambda *a,**k:{'sub':'outsider','email':'outsider@example.com','email_verified':True})
    assert client.post('/auth/google',json={'id_token':'provider-id-token'}).status_code==403
    monkeypatch.setattr(main.id_token,'verify_oauth2_token',lambda *a,**k:{'sub':'owner','email':'inetixus@gmail.com','email_verified':True})
    assert client.post('/auth/google',json={'id_token':'provider-id-token'}).status_code==200
