import { createContext } from 'react';
export const MotionContext = createContext(true);
